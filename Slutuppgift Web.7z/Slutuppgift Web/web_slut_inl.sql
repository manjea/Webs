-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Värd: 127.0.0.1
-- Tid vid skapande: 12 apr 2022 kl 14:42
-- Serverversion: 10.4.21-MariaDB
-- PHP-version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databas: `web_slut_inl`
--

-- --------------------------------------------------------

--
-- Tabellstruktur `article`
--
-- Error reading structure for table web_slut_inl.article: #1932 - Det finns ingen tabell som heter 'web_slut_inl.article' i handlern
-- Error reading data for table web_slut_inl.article: #1064 - Du har något fel i din syntax nära 'FROM `web_slut_inl`.`article`' på rad 1

-- --------------------------------------------------------

--
-- Tabellstruktur `customer`
--
-- Error reading structure for table web_slut_inl.customer: #1932 - Det finns ingen tabell som heter 'web_slut_inl.customer' i handlern
-- Error reading data for table web_slut_inl.customer: #1064 - Du har något fel i din syntax nära 'FROM `web_slut_inl`.`customer`' på rad 1

-- --------------------------------------------------------

--
-- Tabellstruktur `orders`
--
-- Error reading structure for table web_slut_inl.orders: #1932 - Det finns ingen tabell som heter 'web_slut_inl.orders' i handlern
-- Error reading data for table web_slut_inl.orders: #1064 - Du har något fel i din syntax nära 'FROM `web_slut_inl`.`orders`' på rad 1

-- --------------------------------------------------------

--
-- Tabellstruktur `reciept`
--
-- Error reading structure for table web_slut_inl.reciept: #1932 - Det finns ingen tabell som heter 'web_slut_inl.reciept' i handlern
-- Error reading data for table web_slut_inl.reciept: #1064 - Du har något fel i din syntax nära 'FROM `web_slut_inl`.`reciept`' på rad 1
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

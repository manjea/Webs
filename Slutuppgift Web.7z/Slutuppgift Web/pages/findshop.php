<!DOCTYPE html>
<html lang="sv">
    <head>
        <meta charset="utf-8" />
        <title>Sessioner</title>
        <link href="../css/style.css" rel="stylesheet" type="text/css" />
    </head>

    <?php
        // if (session_status() == PHP_SESSION_NONE) { 
        //     session_start(); 
        // }
        // if(isset($_POST['csrf'])){
            
        // if($_SESSION['CSRFToken'] === $_POST['csrf']){
        //     $sant = true;
        // }else{
        //     $sant = false;
        // }
        // }
        // $_SESSION["CSRFToken"] = bin2hex(random_bytes(32));
        
    ?>
    <body>
        <section id="main">
            <h1>Hitta butik</h1>

            <p>Hitta butik ba</p>

            
        </section>
    </body>
</html>
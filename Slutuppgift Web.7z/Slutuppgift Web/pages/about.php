<!DOCTYPE html>
<html lang="sv">
    <head>
        <meta charset="utf-8" />
        <title>Sessioner</title>
        <link href="../css/style.css" rel="stylesheet" type="text/css" />
    </head>

    <body>
        <section id="main">
            <h1>Om</h1>

            <p>about ba</p>

        </section>
    </body>
</html>
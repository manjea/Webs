<footer>
    &copy; Exempelföretag AB
</footer>
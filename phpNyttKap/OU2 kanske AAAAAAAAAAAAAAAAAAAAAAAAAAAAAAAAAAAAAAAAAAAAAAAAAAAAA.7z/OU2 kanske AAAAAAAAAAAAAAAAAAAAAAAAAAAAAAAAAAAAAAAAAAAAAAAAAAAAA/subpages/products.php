<?php//inget att se här?>
<h1>Produkter</h1>

<div id="gallery">
    <div class="image">
        <a target="_blank" href="../img/img1.jpg">
            <img src="./img/img1.jpg" alt="Vara 1" />
        </a>
        <div class="desc">149:-</div>
    </div>
    <div class="image">
        <a target="_blank" href="../img/img2.jpg">
            <img src="./img/img2.jpg" alt="Vara 2" />
        </a>
        <div class="desc">199:-</div>
    </div>
    <div class="image">
        <a target="_blank" href="../img/img3.jpg">
            <img src="./img/img3.jpg" alt="Vara 3" />
        </a>
        <div class="desc">249:-</div>
    </div>
    <div class="image">
        <a target="_blank" href="../img/img4.jpg">
            <img src="./img/img4.jpg" alt="Vara 4" />
        </a>
        <div class="desc">399:</div>
    </div>
    <div class="image">
        <a target="_blank" href="../img/img5.jpg">
            <img src="./img/img5.jpg" alt="Vara 5" />
        </a>
        <div class="desc">479:-</div>
    </div>
    <div class="image">
        <a target="_blank" href="../img/img6.jpg">
            <img src="./img/img6.jpg" alt="Vara 6" />
        </a>
        <div class="desc">599:-</div>
    </div>
</div>

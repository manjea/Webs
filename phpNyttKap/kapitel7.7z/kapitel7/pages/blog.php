<!DOCTYPE html>
<html lang="sv">
    <head>
        <meta charset="utf-8" />
        <title>Sessioner</title>
        <link href="../css/style.css" rel="stylesheet" type="text/css" />
    </head>

    <?php
    session_start();
        if(!isset($_SESSION['loggedIn'])){
            header('Location: ../index.php?msg=Logga in för att få tillgång till blogg');
        }

    ?>
    <body>
        <div id="wrapper">
            <header>
                <h1>Webbserverprogrammering 1</h1>
            </header>

            <section id="leftColumn">
                <nav>
                    <!-- Redigera länkar -->
                    <ul>
                        <li><a href="../index.php">Hem</a></li>
                        <li><a href="contact.php">Kontakt</a></li>
                        <li><a href="blog.php">Blogg</a></li>
                        <?php
                            //session_start();

                            if (isset($_SESSION["loggedIn"])) 
                            { 
                                echo '<li><a href="logout.php">Logga ut</a></li>'; 
                            }
                            else 
                            { 
                                echo '<li><a href="login.php">Logga in</a></li>'; 
                            }
                        ?>
                    </ul>
                </nav>
                <aside>
                    <h1>Beskrivning</h1>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                        Nulla tristique elementum nisl, et vehicula neque laoreet ut. 
                        Praesent sed ultrices purus.
                    </p>
                </aside>
            </section>

            <section id="main">
                <h1>Skapa inlägg</h1>

                <!-- Lägg till formulär -->
                <form action="#" method="post">
                    <fieldset>
                        <legend>Blogg inlägg</legend>
                        <label for="subject">Ämne:</label><br>
                        <input type="text" name="subject" id="subject"><br>
                        <label for="meddelande">Meddelande:</label><br>
                        <textarea style="resize: none;" name="meddelande" id="meddelande" cols="30" rows="10" placeholder="meddelande"></textarea><br><br>

                        <input type="submit" value="submit" name="submit">
                    </fieldset>
                </form>

                <?php
                    if(isset($_POST['submit'])){
                        $subject = "<hr/><p>Ämne: " . $_POST["subject"] . "</p>"; 
                        $msg = "<p>" . $_POST["meddelande"] . "</p>"; 
                        $date = date("Y-m-d H:i:s"); 
                        file_put_contents("../msg.dat", $subject . " " . $msg . " " . $date, FILE_APPEND);

                        if(file_exists("../msg.dat")) 
                        { 
                            echo file_get_contents("msg.dat"); 
                        }
                    }

                    
                ?>
            </section>


            <footer>
                <a href="mailto:mail@doman.se">mail@doman.se</a>
          </footer>
        </div>
    </body>
</html>
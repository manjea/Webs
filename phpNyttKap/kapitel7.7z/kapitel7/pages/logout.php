<?php
    if(!isset($_SESSION['loggedIn'])){
        header('Location: ../index.php?msg=Du är redan utloggad');
    }else{
        session_start();
        session_unset();
        session_destroy();
        header('Location: ../index.php');   
    }





?>
<!DOCTYPE html>
<html lang="sv">
    <head>
        <meta charset="utf-8" />
        <title>Sessioner</title>
        <link href="../css/style.css" rel="stylesheet" type="text/css" />
    </head>

    <body>
        <?php
            session_start();
            if(isset($_SESSION['loggedIn'])){
                header('Location: ../index.php?msg=Du är redan inloggad');
            }


        ?>
        <div id="wrapper">
            <header>
                <h1>Webbserverprogrammering 1</h1>
            </header>

            <section id="leftColumn">
                <nav>
                    <!-- Redigera länkar -->
                    <ul>
                        <li><a href="../index.php">Hem</a></li>
                        <li><a href="contact.php">Kontakt</a></li>
                        <li><a href="blog.php">Blogg</a></li>
                        <?php

                            if (isset($_SESSION["loggedIn"])) 
                            { 
                                echo '<li><a href="logout.php">Logga ut</a></li>'; 
                            }
                            else 
                            { 
                                echo '<li><a href="login.php">Logga in</a></li>'; 
                            }
                        ?>
                    </ul>
                </nav>
                <aside>
                    <h1>Beskrivning</h1>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                        Nulla tristique elementum nisl, et vehicula neque laoreet ut. 
                        Praesent sed ultrices purus.
                    </p>
                </aside>
            </section>

            <section id="main">
                <h1>Logga in</h1>

                <!-- Lägg till formulär -->

                <form action="#" method="post">
                    <fieldset>
                        <legend>Loggin</legend>
                    
                        <label for="namn">Username:</label><br>
                        <input type="text" name="namn" id="namn"><br>

                        <label for="pass">Password:</label><br>
                        <input type="text" name="pass" id="pass"><br>
                        <br>
                        <input type="submit" value="login" name="submit">
                    </fieldset>

                </form>
            </section>

            <footer>
                <a href="mailto:mail@doman.se">mail@doman.se</a>
            </footer>
        </div>
    </body>
    <?php
        session_start();

        if(isset($_POST['submit'])){
                        
            $namn =  $_POST['namn'];
            $pass = $_POST['pass'];
            if ($namn == 'root' && $pass == 'admin') {
                $_SESSION["loggedIn"] = true;
                header('Location: ../index.php');
            }else{
                echo 'felaktiga uppgifter';
            }
        }
    ?>
</html>
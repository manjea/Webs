<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Sessioner</title>
        <link href="../css/style.css" rel="stylesheet" />
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="../index.php">Hem</a></li>
                <li><a href="products.php">Produkter</a></li>
                <li><a href="contact.php">Kontakt</a></li>
                <li><a href="shop.php">Handla</a></li>
                <li id="right"><a href="login.php">Logga in</a></li>
            </ul>
        </nav>
        <section>
            <h1>Handla</h1>

            <article id="articleLeft">
                <p>Beställningsinformation:</p>

                <!-- Lägg till utskrift om kostnad -->
            </article>

            <article id="articleRight">
                <form action="#" method="post">
                    <fieldset>
                        <legend>Köp</legend>
                        <p>
                            <label for="p">Välj vara</label>
                            <select name="priser" id="p">
                                <option value="149">Vara 1 (149:-)</option>
                                <option value="199">Vara 2 (199:-)</option>
                                <option value="249">Vara 3 (249:-)</option>
                                <option value="399">Vara 4 (399:-)</option>
                                <option value="479">Vara 5 (479:-)</option>
                                <option value="599">Vara 6 (599:-)</option>
                            </select>
                        </p>
                        <p>
                            <label>Antal <br />
                                <input type="number" placeholder="Ex. 1" required />
                            </label>
                        </p>
                        <p>
                            <input type="submit" value="Lägg till i varukorg" />
                        </p>
                    </fieldset>
                </form>
            </article>
        </section>
        <footer>
            &copy; Exempelföretag AB
        </footer>
    </body>
</html>
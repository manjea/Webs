<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Sessioner</title>
        <link href="../css/style.css" rel="stylesheet" />
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="../index.php">Hem</a></li>
                <li><a href="products.php">Produkter</a></li>
                <li><a href="contact.php">Kontakt</a></li>
                <li><a href="shop.php">Handla</a></li>
                <li id="right"><a href="login.php">Logga in</a></li>
            </ul>
        </nav>
        <section>
            <h1>Produkter</h1>

            <div id="gallery">
                <div class="image">
                    <a target="_blank" href="../img/img1.jpg">
                        <img src="../img/img1.jpg" alt="Vara 1" />
                    </a>
                    <div class="desc">149:-</div>
                </div>
                <div class="image">
                    <a target="_blank" href="../img/img2.jpg">
                        <img src="../img/img2.jpg" alt="Vara 2" />
                    </a>
                    <div class="desc">199:-</div>
                </div>
                <div class="image">
                    <a target="_blank" href="../img/img3.jpg">
                        <img src="../img/img3.jpg" alt="Vara 3" />
                    </a>
                    <div class="desc">249:-</div>
                </div>
                <div class="image">
                    <a target="_blank" href="../img/img4.jpg">
                        <img src="../img/img4.jpg" alt="Vara 4" />
                    </a>
                    <div class="desc">399:</div>
                </div>
                <div class="image">
                    <a target="_blank" href="../img/img5.jpg">
                        <img src="../img/img5.jpg" alt="Vara 5" />
                    </a>
                    <div class="desc">479:-</div>
                </div>
                <div class="image">
                    <a target="_blank" href="../img/img6.jpg">
                        <img src="../img/img6.jpg" alt="Vara 6" />
                    </a>
                    <div class="desc">599:-</div>
                </div>
            </div>
        </section>
        <footer>
            &copy; Exempelföretag AB
        </footer>
    </body>
</html>
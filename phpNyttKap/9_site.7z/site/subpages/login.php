<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Sessioner</title>
        <link href="../css/style.css" rel="stylesheet" />
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="../index.php">Hem</a></li>
                <li><a href="products.php">Produkter</a></li>
                <li><a href="contact.php">Kontakt</a></li>
                <li><a href="shop.php">Handla</a></li>
                <li id="right"><a href="login.php">Logga in</a></li>
            </ul>
        </nav>
        <section>
            <form id="formLogin" action="#" method="post">
                <fieldset>
                    <legend>Logga in</legend>
                    <p>
                        <label>Användarnamn <br />
                            <input type="text" placeholder="User123" required />
                        </label>
                    </p>
                    <p>
                        <label>Lösenord <br />
                            <input type="password" placeholder="Lösenord" required />
                        </label>
                    </p>
                    <p>
                        <input type="submit" value="Skicka" />
                    </p>
                </fieldset>
            </form>
        </section>
        <footer>
            &copy; Exempelföretag AB
        </footer>
    </body>
</html>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Sessioner</title>
        <link href="../css/style.css" rel="stylesheet" />
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="../index.php">Hem</a></li>
                <li><a href="products.php">Produkter</a></li>
                <li><a href="contact.php">Kontakt</a></li>
                <li><a href="shop.php">Handla</a></li>
                <li id="right"><a href="login.php">Logga in</a></li>
            </ul>
        </nav>
        <section>
            <h1>Kontakt</h1>

            <article id="articleLeft">
                <p>Exempelföretag AB</p>
                <p>Öppettider: Vardagar 10 - 19</p>
                <p>Telefonnummer: 010-12345678</p>
                <p>Adress: 12345 City</p>
            </article>

            <article id="articleRight">
                <form action="#" method="post">
                    <fieldset>
                        <legend>Skicka ett meddelande</legend>
                        <p>
                            <label>Namn <br />
                                <input type="text" placeholder="Johan Englund" required />
                            </label>
                        </p>
                        <p>
                            <label>Mail <br />
                                <input type="email" placeholder="example@example.com" required />
                            </label>
                        </p>
                        <p>
                            <label>Meddelande <br />
                                <textarea placeholder="Max 200 tecken" cols="25" rows="5" maxlength="200" required></textarea>
                            </label>
                        </p>
                        <p>
                            <input type="submit" value="Skicka" />
                        </p>
                    </fieldset>
                </form>
            </article>
        </section>
        <footer>
            &copy; Exempelföretag AB
        </footer>
    </body>
</html>
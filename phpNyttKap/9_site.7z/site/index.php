<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Sessioner</title>
        <link href="css/style.css" rel="stylesheet" />
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="index.php">Hem</a></li>
                <li><a href="subpages/products.php">Produkter</a></li>
                <li><a href="subpages/contact.php">Kontakt</a></li>
                <li><a href="subpages/shop.php">Handla</a></li>
                <li id="right"><a href="subpages/login.php">Logga in</a></li>
            </ul>
        </nav>
        <section>
            <h1>Startsida</h1>
            <article>
                <p>Detta är webbsidans startsida</p>

                <!-- Lägg till utskrift om man är inloggad eller inte -->
                
            </article>

            <article style="margin-top:40px">
                <h3>Nyheter</h3>
                <p>Innehåll</p>
            </article>
        </section>
        <footer>
            &copy; Exempelföretag AB
        </footer>
    </body>
</html>
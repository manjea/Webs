<?php
    $users = ["admin" => "admin"];



?>
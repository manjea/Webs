<?php
    echo "välkommen " . $_GET['anvn'];

?>
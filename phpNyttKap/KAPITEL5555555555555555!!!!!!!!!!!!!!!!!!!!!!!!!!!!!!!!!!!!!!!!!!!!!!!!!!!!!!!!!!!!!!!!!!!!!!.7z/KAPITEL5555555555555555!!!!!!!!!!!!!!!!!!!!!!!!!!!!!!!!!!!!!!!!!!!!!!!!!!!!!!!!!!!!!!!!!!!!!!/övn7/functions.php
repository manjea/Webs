<?php
    function add($n1, $n2){
        return $n1 + $n2;
    }

    function subt($n1, $n2){
        return $n1 - $n2;
    }

    function tim($n1, $n2){
        return $n1 * $n2;
    }

    function div($n1, $n2){
        return $n1 / $n2;
    }
?>
<?php

    function sayHello($x){
        for($i = 0; $i<$x; $i++){
            echo "Hello World! ";
        }
    }
    
    sayHello(50);












?>
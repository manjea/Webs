<?php

    $text = "På en mattelektion behöver man";

    $text .= ", penna";
    $text .= ", block";
    $text .= " och sin räknare."; #la till '.'

    echo $text;



?>
<?php
    $a = 10;
    $b = 2;

    echo "Addition: " . $a + $b . "<br>";
    echo "Subtraktion: " . $a - $b . "<br>";
    echo "Multiplikation: " . $a * $b . "<br>";
    echo "Division: " . $a / $b . "<br>";
    echo "Modulus: " . $a%$b . "<br>";
    echo "Upphöjt: " . ($a^$b) . "<br>";



?>
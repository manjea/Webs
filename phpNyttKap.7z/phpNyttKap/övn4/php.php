<?php
    $a = "Sju gånger sju är 49";
    $b = "3 små grisar";
    $c = "1300";
    $d = "4.85" + 30;
    $e = "";

    echo $c + $d . "<br>";
    echo $c + (float)$d . "<br>";
    echo (int)$a + (int)$b + (int)$c + (int)$d + (int)$c . "<br>";
?>
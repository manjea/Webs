<?php
    $number = 5;

    $number += 5;
    $number *= 6;
    $number++;
    $number--;
    $number /= 2;

    echo $number;

    #30


?>